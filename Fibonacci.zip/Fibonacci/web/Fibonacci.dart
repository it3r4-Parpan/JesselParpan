import 'dart:io';

bool checkFibonacci(List<int> list) {
  for (int i = 2; i < list.length; i++) {
    if ((list[i - 1] + list[i - 2]) != list[i]) {
      return false;
    }
  }
  return true;
}

void main() {
  print("Fibbonacci Checker \n");
  List<int> list = new List();
  print("Input size of list(size must be greater than 3 less than 10): ");
  int size = int.parse(stdin.readLineSync());
  if (size < 3 || size > 10) {
    print("Invalid size");
  } else {
    for (int i = 0; i < size; i++) {
      int a = i + 1;
      print("Input numbers $a: ");
      list.add(int.parse(stdin.readLineSync()));
    }
    print(list);
    print(checkFibonacci(list));
  }
}
